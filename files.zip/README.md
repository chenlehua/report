# TARA Excel报告生成器使用说明

## 概述

本工具用于生成车载信息娱乐系统(IVI)的威胁分析和风险评估(TARA)报告Excel文件。

## 文件清单

| 文件 | 说明 |
|------|------|
| `tara_excel_generator.py` | 主程序模块 |
| `test_tara_excel_generator.py` | 单元测试文件 (23个测试用例) |
| `sample_input_data.json` | JSON输入数据示例 |
| `tara_report_generated.xlsx` | 生成的示例Excel报告 |

## 输入数据格式说明

### 总体JSON结构

```json
{
  "cover": { ... },           // TAB0: 封面数据
  "definitions": { ... },     // TAB1: 相关定义数据
  "assets": { ... },          // TAB2: 资产列表数据
  "attack_trees": { ... },    // TAB3: 攻击树数据
  "tara_results": { ... }     // TAB4: TARA分析结果数据
}
```

---

### TAB0: 封面 (cover)

```json
{
  "cover": {
    "report_title": "威胁分析和风险评估报告",
    "report_title_en": "Threat Analysis And Risk Assessment Report",
    "project_name": "——DiLink150中控主机平台",
    "data_level": "秘密",
    "document_number": "IPC0011_JF_A30-44003",
    "version": "V1.0",
    "author_date": "2025.11",
    "review_date": "2025.12",
    "sign_date": "",
    "approve_date": ""
  }
}
```

| 字段 | 类型 | 说明 |
|------|------|------|
| report_title | string | 报告标题(中文) |
| report_title_en | string | 报告标题(英文) |
| project_name | string | 项目名称 |
| data_level | string | 数据等级 |
| document_number | string | 文档编号 |
| version | string | 版本号 |
| author_date | string | 编制日期 |
| review_date | string | 审核日期 |
| sign_date | string | 会签日期 |
| approve_date | string | 批准日期 |

---

### TAB1: 相关定义 (definitions)

```json
{
  "definitions": {
    "title": "MY25 EV平台中控主机 TARA分析报告 - 相关定义",
    "functional_description": "车载信息娱乐系统描述文本...",
    "item_boundary_image": "/path/to/boundary.png",
    "system_architecture_image": "/path/to/system_arch.png",
    "software_architecture_image": "/path/to/software_arch.png",
    "assumptions": [
      {"id": "ASM-01", "description": "假设描述1"},
      {"id": "ASM-02", "description": "假设描述2"}
    ],
    "terminology": [
      {"abbreviation": "IVI", "english": "In-Vehicle Infotainment", "chinese": "车载信息娱乐系统"},
      {"abbreviation": "TARA", "english": "Threat Analysis and Risk Assessment", "chinese": "威胁分析与风险评估"}
    ]
  }
}
```

| 字段 | 类型 | 说明 |
|------|------|------|
| title | string | 页面标题 |
| functional_description | string | 功能描述文本 |
| item_boundary_image | string | 项目边界图片路径 |
| system_architecture_image | string | 系统架构图片路径 |
| software_architecture_image | string | 软件架构图片路径 |
| assumptions | array | 假设列表 |
| assumptions[].id | string | 假设编号 |
| assumptions[].description | string | 假设描述 |
| terminology | array | 术语列表 |
| terminology[].abbreviation | string | 缩写 |
| terminology[].english | string | 英文全称 |
| terminology[].chinese | string | 中文全称 |

---

### TAB2: 资产列表 (assets)

```json
{
  "assets": {
    "title": "MY25 EV平台中控主机- 资产列表 Asset List",
    "dataflow_image": "/path/to/dataflow.png",
    "assets": [
      {
        "id": "P001",
        "name": "SOC",
        "category": "内部实体",
        "remarks": "主处理器芯片",
        "authenticity": true,
        "integrity": false,
        "non_repudiation": false,
        "confidentiality": false,
        "availability": true,
        "authorization": false
      }
    ]
  }
}
```

| 字段 | 类型 | 说明 |
|------|------|------|
| title | string | 页面标题 |
| dataflow_image | string | 数据流图片路径 |
| assets | array | 资产列表 |
| assets[].id | string | 资产ID (P=处理, E=外部实体, S=存储, D=数据流, A=应用) |
| assets[].name | string | 资产名称 |
| assets[].category | string | 分类 (内部实体/外部实体/数据存储/数据流/固件及应用) |
| assets[].remarks | string | 备注 |
| assets[].authenticity | boolean | 真实性属性 |
| assets[].integrity | boolean | 完整性属性 |
| assets[].non_repudiation | boolean | 不可抵赖性属性 |
| assets[].confidentiality | boolean | 机密性属性 |
| assets[].availability | boolean | 可用性属性 |
| assets[].authorization | boolean | 权限属性 |

---

### TAB3: 攻击树 (attack_trees)

```json
{
  "attack_trees": {
    "title": "MY25 EV平台中控主机 - 攻击树分析 Attack Tree Analysis",
    "attack_trees": [
      {"title": "攻击树1: 远程入侵IVI系统", "image": "/path/to/attack_tree_1.png"},
      {"title": "攻击树2: 物理接口攻击", "image": "/path/to/attack_tree_2.png"}
    ]
  }
}
```

| 字段 | 类型 | 说明 |
|------|------|------|
| title | string | 页面标题 |
| attack_trees | array | 攻击树列表 |
| attack_trees[].title | string | 攻击树标题 |
| attack_trees[].image | string | 攻击树图片路径 |

---

### TAB4: TARA分析结果 (tara_results)

```json
{
  "tara_results": {
    "title": "MY25 EV平台中控主机_TARA分析结果",
    "results": [
      {
        "asset_id": "P001",
        "asset_name": "车载多媒体",
        "subdomain1": "系统实体",
        "subdomain2": "N/A",
        "subdomain3": "SOC",
        "category": "内部实体",
        "security_attribute": "Authenticity\n真实性",
        "stride_model": "S欺骗",
        "threat_scenario": "威胁场景描述...",
        "attack_path": "攻击路径描述...",
        "wp29_mapping": "4.1\n5.1",
        "attack_vector": "本地",
        "attack_complexity": "低",
        "privileges_required": "低",
        "user_interaction": "不需要",
        "safety_impact": "中等的",
        "financial_impact": "中等的",
        "operational_impact": "重大的",
        "privacy_impact": "可忽略不计的",
        "security_requirement": "安全需求描述..."
      }
    ]
  }
}
```

| 字段 | 类型 | 说明 | 可选值 |
|------|------|------|--------|
| asset_id | string | 资产ID | - |
| asset_name | string | 资产名称 | - |
| subdomain1 | string | 子领域一 | - |
| subdomain2 | string | 子领域二 | - |
| subdomain3 | string | 子领域三 | - |
| category | string | 分类 | - |
| security_attribute | string | 安全属性 | Authenticity, Integrity, Non-Repudiation, Confidentiality, Availability, Elevation of Privilege |
| stride_model | string | STRIDE模型 | S欺骗, T篡改, R抵赖, I信息泄露, D拒绝服务, E权限提升 |
| threat_scenario | string | 威胁场景 | - |
| attack_path | string | 攻击路径 | - |
| wp29_mapping | string | WP29威胁映射 | - |
| attack_vector | string | 攻击向量 | 网络, 邻居, 本地, 物理 |
| attack_complexity | string | 攻击复杂度 | 低, 高 |
| privileges_required | string | 权限要求 | 无, 低, 高 |
| user_interaction | string | 用户交互 | 不需要, 需要 |
| safety_impact | string | 安全影响 | 可忽略不计的, 中等的, 重大的, 严重的 |
| financial_impact | string | 经济影响 | 可忽略不计的, 中等的, 重大的, 严重的 |
| operational_impact | string | 操作影响 | 可忽略不计的, 中等的, 重大的, 严重的 |
| privacy_impact | string | 隐私影响 | 可忽略不计的, 中等的, 重大的, 严重的 |
| security_requirement | string | 安全需求 | - |

---

## 使用方法

### 方法1: 使用JSON文件

```python
import json
from tara_excel_generator import generate_tara_excel_from_json

# 读取JSON数据
with open('input_data.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

# 生成Excel
generate_tara_excel_from_json('output_report.xlsx', data)
```

### 方法2: 直接传入字典

```python
from tara_excel_generator import generate_tara_excel

generate_tara_excel(
    output_path='output_report.xlsx',
    cover_data={...},
    definitions_data={...},
    assets_data={...},
    attack_trees_data={...},
    tara_results_data={...}
)
```

---

## 自动计算公式

TAB4中的以下字段会自动生成Excel公式进行计算：

| 列 | 说明 | 公式逻辑 |
|----|------|----------|
| M | 攻击向量值 | 网络=0.85, 邻居=0.62, 本地=0.55, 物理=0.2 |
| O | 攻击复杂度值 | 低=0.77, 高=0.44 |
| Q | 权限要求值 | 无=0.85, 低=0.62, 高=0.27 |
| S | 用户交互值 | 不需要=0.85, 需要=0.62 |
| T | 攻击可行性计算 | =8.22×M×O×Q×S |
| U | 攻击可行性等级 | 根据T值判断：很低/低/中/高/很高 |
| X/AA/AD/AG | 影响值 | 可忽略不计的=0, 中等的=1, 重大的=10, 严重的=1000 |
| AH | 影响计算 | =SUM(X+AA+AD+AG) |
| AI | 影响等级 | 根据AH值判断 |
| AJ | 风险等级 | 根据AI和U组合判断：QM/Low/Medium/High/Critical |
| AK | 风险处置决策 | 根据AJ判断：保留风险/降低风险/规避风险 |
| AN | WP29控制映射 | 根据STRIDE模型自动映射 |

---

## 运行单元测试

```bash
python -m unittest test_tara_excel_generator -v
```

测试覆盖23个测试用例，包括：
- 样式常量测试
- 各Sheet创建测试
- 数据完整性测试
- 公式测试
- 边界情况测试
- 集成测试

---

## 依赖

- Python 3.8+
- openpyxl
- Pillow (用于图片处理)

```bash
pip install openpyxl Pillow
```
