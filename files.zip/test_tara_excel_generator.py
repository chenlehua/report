"""
TARA Excel生成器单元测试
"""

import unittest
import os
import json
import tempfile
from openpyxl import load_workbook
from tara_excel_generator import (
    generate_tara_excel,
    generate_tara_excel_from_json,
    TARAStyles
)


class TestTARAStyles(unittest.TestCase):
    """测试样式常量"""
    
    def test_color_constants(self):
        """测试颜色常量定义"""
        self.assertEqual(TARAStyles.DARK_BLUE, "FF2F5496")
        self.assertEqual(TARAStyles.MEDIUM_BLUE, "FF4472C4")
        self.assertEqual(TARAStyles.LIGHT_BLUE, "FF8EA9DB")
        self.assertEqual(TARAStyles.WHITE, "FFFFFFFF")
    
    def test_font_definitions(self):
        """测试字体定义"""
        self.assertIsNotNone(TARAStyles.TITLE_FONT)
        self.assertEqual(TARAStyles.TITLE_FONT.size, 16)
        self.assertTrue(TARAStyles.TITLE_FONT.bold)
    
    def test_fill_definitions(self):
        """测试填充样式定义"""
        self.assertIsNotNone(TARAStyles.SECTION_FILL)
        self.assertEqual(TARAStyles.SECTION_FILL.fill_type, 'solid')


class TestCoverSheet(unittest.TestCase):
    """测试封面Sheet生成"""
    
    def setUp(self):
        """设置测试数据"""
        self.cover_data = {
            "report_title": "威胁分析和风险评估报告",
            "report_title_en": "Threat Analysis And Risk Assessment Report",
            "project_name": "——测试项目平台",
            "data_level": "秘密",
            "document_number": "TEST-001",
            "version": "V1.0",
            "author_date": "2025.11",
            "review_date": "2025.12"
        }
        self.output_path = tempfile.mktemp(suffix='.xlsx')
    
    def tearDown(self):
        """清理测试文件"""
        if os.path.exists(self.output_path):
            os.remove(self.output_path)
    
    def test_cover_sheet_creation(self):
        """测试封面Sheet创建"""
        result = generate_tara_excel(
            self.output_path,
            cover_data=self.cover_data,
            definitions_data={},
            assets_data={},
            attack_trees_data={},
            tara_results_data={}
        )
        
        self.assertTrue(os.path.exists(result))
        
        wb = load_workbook(result)
        self.assertIn("0. 封面 Front Cover", wb.sheetnames)
        
        ws = wb["0. 封面 Front Cover"]
        self.assertIn("秘密", str(ws['F4'].value))
        self.assertIn("TEST-001", str(ws['F5'].value))


class TestDefinitionsSheet(unittest.TestCase):
    """测试相关定义Sheet生成"""
    
    def setUp(self):
        """设置测试数据"""
        self.definitions_data = {
            "title": "测试项目 TARA分析报告 - 相关定义",
            "functional_description": "这是一个测试用的功能描述文本。",
            "assumptions": [
                {"id": "ASM-01", "description": "测试假设1"},
                {"id": "ASM-02", "description": "测试假设2"},
                {"id": "ASM-03", "description": "测试假设3"}
            ],
            "terminology": [
                {"abbreviation": "IVI", "english": "In-Vehicle Infotainment", "chinese": "车载信息娱乐系统"},
                {"abbreviation": "TARA", "english": "Threat Analysis and Risk Assessment", "chinese": "威胁分析与风险评估"},
                {"abbreviation": "SOC", "english": "System on Chip", "chinese": "片上系统"}
            ]
        }
        self.output_path = tempfile.mktemp(suffix='.xlsx')
    
    def tearDown(self):
        """清理测试文件"""
        if os.path.exists(self.output_path):
            os.remove(self.output_path)
    
    def test_definitions_sheet_creation(self):
        """测试相关定义Sheet创建"""
        result = generate_tara_excel(
            self.output_path,
            cover_data={},
            definitions_data=self.definitions_data,
            assets_data={},
            attack_trees_data={},
            tara_results_data={}
        )
        
        self.assertTrue(os.path.exists(result))
        
        wb = load_workbook(result)
        self.assertIn("1-相关定义", wb.sheetnames)
    
    def test_assumptions_count(self):
        """测试假设数量正确"""
        result = generate_tara_excel(
            self.output_path,
            cover_data={},
            definitions_data=self.definitions_data,
            assets_data={},
            attack_trees_data={},
            tara_results_data={}
        )
        
        wb = load_workbook(result)
        ws = wb["1-相关定义"]
        
        # 查找假设内容
        assumption_count = 0
        for row in ws.iter_rows():
            for cell in row:
                if cell.value and "ASM-0" in str(cell.value):
                    assumption_count += 1
        
        self.assertEqual(assumption_count, 3)
    
    def test_terminology_count(self):
        """测试术语数量正确"""
        result = generate_tara_excel(
            self.output_path,
            cover_data={},
            definitions_data=self.definitions_data,
            assets_data={},
            attack_trees_data={},
            tara_results_data={}
        )
        
        wb = load_workbook(result)
        ws = wb["1-相关定义"]
        
        # 查找术语
        term_count = 0
        for row in ws.iter_rows():
            for cell in row:
                if cell.value and cell.value in ["IVI", "TARA", "SOC"]:
                    term_count += 1
        
        self.assertGreaterEqual(term_count, 3)


class TestAssetsSheet(unittest.TestCase):
    """测试资产列表Sheet生成"""
    
    def setUp(self):
        """设置测试数据"""
        self.assets_data = {
            "title": "测试项目 - 资产列表",
            "assets": [
                {
                    "id": "P001", "name": "SOC", "category": "内部实体",
                    "remarks": "主处理器芯片",
                    "authenticity": True, "integrity": False, "non_repudiation": False,
                    "confidentiality": False, "availability": True, "authorization": False
                },
                {
                    "id": "P002", "name": "MCU", "category": "内部实体",
                    "remarks": "微控制器",
                    "authenticity": True, "integrity": True, "non_repudiation": False,
                    "confidentiality": False, "availability": True, "authorization": False
                },
                {
                    "id": "E001", "name": "TBox", "category": "外部实体",
                    "remarks": "远程信息处理器",
                    "authenticity": True, "integrity": False, "non_repudiation": False,
                    "confidentiality": False, "availability": False, "authorization": False
                }
            ]
        }
        self.output_path = tempfile.mktemp(suffix='.xlsx')
    
    def tearDown(self):
        """清理测试文件"""
        if os.path.exists(self.output_path):
            os.remove(self.output_path)
    
    def test_assets_sheet_creation(self):
        """测试资产列表Sheet创建"""
        result = generate_tara_excel(
            self.output_path,
            cover_data={},
            definitions_data={},
            assets_data=self.assets_data,
            attack_trees_data={},
            tara_results_data={}
        )
        
        self.assertTrue(os.path.exists(result))
        
        wb = load_workbook(result)
        self.assertIn("2-资产列表&数据流图", wb.sheetnames)
    
    def test_assets_data_correct(self):
        """测试资产数据正确写入"""
        result = generate_tara_excel(
            self.output_path,
            cover_data={},
            definitions_data={},
            assets_data=self.assets_data,
            attack_trees_data={},
            tara_results_data={}
        )
        
        wb = load_workbook(result)
        ws = wb["2-资产列表&数据流图"]
        
        # 检查资产ID
        asset_ids = []
        for row in ws.iter_rows(min_row=5, max_col=1):
            if row[0].value and row[0].value.startswith(('P', 'E', 'S', 'D', 'A')):
                asset_ids.append(row[0].value)
        
        self.assertIn("P001", asset_ids)
        self.assertIn("P002", asset_ids)
        self.assertIn("E001", asset_ids)
    
    def test_security_attributes_checkbox(self):
        """测试安全属性勾选正确"""
        result = generate_tara_excel(
            self.output_path,
            cover_data={},
            definitions_data={},
            assets_data=self.assets_data,
            attack_trees_data={},
            tara_results_data={}
        )
        
        wb = load_workbook(result)
        ws = wb["2-资产列表&数据流图"]
        
        # 检查第一个资产的勾选
        # P001: authenticity=True, availability=True
        # 数据从第5行开始，E列是authenticity，I列是availability
        self.assertEqual(ws['E5'].value, '√')
        self.assertEqual(ws['I5'].value, '√')
        self.assertNotEqual(ws['F5'].value, '√')  # integrity=False


class TestAttackTreesSheet(unittest.TestCase):
    """测试攻击树Sheet生成"""
    
    def setUp(self):
        """设置测试数据"""
        self.attack_trees_data = {
            "title": "测试项目 - 攻击树分析",
            "attack_trees": [
                {"title": "攻击树1: 远程入侵系统", "image": ""},
                {"title": "攻击树2: 物理接口攻击", "image": ""},
                {"title": "攻击树3: 数据窃取", "image": ""},
                {"title": "攻击树4: 恶意控制", "image": ""}
            ]
        }
        self.output_path = tempfile.mktemp(suffix='.xlsx')
    
    def tearDown(self):
        """清理测试文件"""
        if os.path.exists(self.output_path):
            os.remove(self.output_path)
    
    def test_attack_trees_sheet_creation(self):
        """测试攻击树Sheet创建"""
        result = generate_tara_excel(
            self.output_path,
            cover_data={},
            definitions_data={},
            assets_data={},
            attack_trees_data=self.attack_trees_data,
            tara_results_data={}
        )
        
        self.assertTrue(os.path.exists(result))
        
        wb = load_workbook(result)
        self.assertIn("3-攻击树图", wb.sheetnames)
    
    def test_attack_trees_titles(self):
        """测试攻击树标题正确"""
        result = generate_tara_excel(
            self.output_path,
            cover_data={},
            definitions_data={},
            assets_data={},
            attack_trees_data=self.attack_trees_data,
            tara_results_data={}
        )
        
        wb = load_workbook(result)
        ws = wb["3-攻击树图"]
        
        # 查找标题
        titles_found = []
        for row in ws.iter_rows():
            for cell in row:
                if cell.value and "攻击树" in str(cell.value):
                    titles_found.append(cell.value)
        
        self.assertGreaterEqual(len(titles_found), 4)


class TestTARAResultsSheet(unittest.TestCase):
    """测试TARA分析结果Sheet生成"""
    
    def setUp(self):
        """设置测试数据"""
        self.tara_results_data = {
            "title": "测试项目_TARA分析结果",
            "results": [
                {
                    "asset_id": "P001", "asset_name": "车载多媒体",
                    "subdomain1": "系统实体", "subdomain2": "N/A", "subdomain3": "SOC",
                    "category": "内部实体", "security_attribute": "Authenticity\n真实性",
                    "stride_model": "S欺骗", "threat_scenario": "黑客仿冒SOC模块",
                    "attack_path": "攻击者锁定目标车辆", "wp29_mapping": "4.1",
                    "attack_vector": "本地", "attack_complexity": "低",
                    "privileges_required": "低", "user_interaction": "不需要",
                    "safety_impact": "中等的", "financial_impact": "中等的",
                    "operational_impact": "重大的", "privacy_impact": "可忽略不计的",
                    "security_requirement": "确保安全启动"
                },
                {
                    "asset_id": "P001", "asset_name": "车载多媒体",
                    "subdomain1": "系统实体", "subdomain2": "N/A", "subdomain3": "SOC",
                    "category": "内部实体", "security_attribute": "Availability\n可用性",
                    "stride_model": "D拒绝服务", "threat_scenario": "DoS攻击",
                    "attack_path": "攻击者发送大量请求", "wp29_mapping": "8.1",
                    "attack_vector": "网络", "attack_complexity": "高",
                    "privileges_required": "无", "user_interaction": "不需要",
                    "safety_impact": "可忽略不计的", "financial_impact": "中等的",
                    "operational_impact": "重大的", "privacy_impact": "可忽略不计的",
                    "security_requirement": "实施流量限制"
                }
            ]
        }
        self.output_path = tempfile.mktemp(suffix='.xlsx')
    
    def tearDown(self):
        """清理测试文件"""
        if os.path.exists(self.output_path):
            os.remove(self.output_path)
    
    def test_tara_results_sheet_creation(self):
        """测试TARA结果Sheet创建"""
        result = generate_tara_excel(
            self.output_path,
            cover_data={},
            definitions_data={},
            assets_data={},
            attack_trees_data={},
            tara_results_data=self.tara_results_data
        )
        
        self.assertTrue(os.path.exists(result))
        
        wb = load_workbook(result)
        self.assertIn("4-TARA分析结果", wb.sheetnames)
    
    def test_tara_results_formulas(self):
        """测试TARA结果公式正确"""
        result = generate_tara_excel(
            self.output_path,
            cover_data={},
            definitions_data={},
            assets_data={},
            attack_trees_data={},
            tara_results_data=self.tara_results_data
        )
        
        wb = load_workbook(result)
        ws = wb["4-TARA分析结果"]
        
        # 检查公式存在（数据从第6行开始）
        # M列应该有攻击向量值的公式
        cell_m6 = ws['M6'].value
        self.assertIsNotNone(cell_m6)
        self.assertTrue(str(cell_m6).startswith('='))
        
        # T列应该有攻击可行性计算公式
        cell_t6 = ws['T6'].value
        self.assertIsNotNone(cell_t6)
        self.assertTrue(str(cell_t6).startswith('='))
    
    def test_tara_results_data_count(self):
        """测试TARA结果数据行数正确"""
        result = generate_tara_excel(
            self.output_path,
            cover_data={},
            definitions_data={},
            assets_data={},
            attack_trees_data={},
            tara_results_data=self.tara_results_data
        )
        
        wb = load_workbook(result)
        ws = wb["4-TARA分析结果"]
        
        # 统计数据行数（从第6行开始）
        data_rows = 0
        for row in range(6, ws.max_row + 1):
            if ws[f'A{row}'].value:
                data_rows += 1
        
        self.assertEqual(data_rows, 2)


class TestJSONInput(unittest.TestCase):
    """测试JSON输入功能"""
    
    def setUp(self):
        """设置测试数据"""
        self.json_data = {
            "cover": {
                "report_title": "测试报告",
                "project_name": "测试项目",
                "data_level": "内部",
                "document_number": "JSON-TEST-001"
            },
            "definitions": {
                "title": "测试定义",
                "functional_description": "JSON测试功能描述",
                "assumptions": [
                    {"id": "ASM-01", "description": "JSON测试假设"}
                ],
                "terminology": [
                    {"abbreviation": "TEST", "english": "Test", "chinese": "测试"}
                ]
            },
            "assets": {
                "title": "测试资产",
                "assets": [
                    {"id": "T001", "name": "测试资产", "category": "测试"}
                ]
            },
            "attack_trees": {
                "title": "测试攻击树",
                "attack_trees": [
                    {"title": "测试攻击树1", "image": ""}
                ]
            },
            "tara_results": {
                "title": "测试结果",
                "results": []
            }
        }
        self.output_path = tempfile.mktemp(suffix='.xlsx')
    
    def tearDown(self):
        """清理测试文件"""
        if os.path.exists(self.output_path):
            os.remove(self.output_path)
    
    def test_json_input_generation(self):
        """测试JSON输入生成Excel"""
        result = generate_tara_excel_from_json(self.output_path, self.json_data)
        
        self.assertTrue(os.path.exists(result))
        
        wb = load_workbook(result)
        self.assertEqual(len(wb.sheetnames), 5)
    
    def test_json_string_input(self):
        """测试JSON字符串转换后输入"""
        json_str = json.dumps(self.json_data, ensure_ascii=False)
        parsed_data = json.loads(json_str)
        
        result = generate_tara_excel_from_json(self.output_path, parsed_data)
        
        self.assertTrue(os.path.exists(result))


class TestEdgeCases(unittest.TestCase):
    """测试边界情况"""
    
    def setUp(self):
        """设置测试环境"""
        self.output_path = tempfile.mktemp(suffix='.xlsx')
    
    def tearDown(self):
        """清理测试文件"""
        if os.path.exists(self.output_path):
            os.remove(self.output_path)
    
    def test_empty_data(self):
        """测试空数据输入"""
        result = generate_tara_excel(
            self.output_path,
            cover_data={},
            definitions_data={},
            assets_data={},
            attack_trees_data={},
            tara_results_data={}
        )
        
        self.assertTrue(os.path.exists(result))
        
        wb = load_workbook(result)
        self.assertEqual(len(wb.sheetnames), 5)
    
    def test_special_characters(self):
        """测试特殊字符处理"""
        special_data = {
            "cover": {
                "report_title": "测试<>&\"'报告",
                "project_name": "特殊字符：!@#$%^&*()"
            }
        }
        
        result = generate_tara_excel(
            self.output_path,
            cover_data=special_data.get('cover', {}),
            definitions_data={},
            assets_data={},
            attack_trees_data={},
            tara_results_data={}
        )
        
        self.assertTrue(os.path.exists(result))
    
    def test_long_text(self):
        """测试长文本处理"""
        long_text = "这是一段非常长的测试文本，" * 100
        
        definitions_data = {
            "functional_description": long_text
        }
        
        result = generate_tara_excel(
            self.output_path,
            cover_data={},
            definitions_data=definitions_data,
            assets_data={},
            attack_trees_data={},
            tara_results_data={}
        )
        
        self.assertTrue(os.path.exists(result))
    
    def test_unicode_characters(self):
        """测试Unicode字符处理"""
        unicode_data = {
            "cover": {
                "report_title": "报告 📊 测试 🚗 车辆",
                "project_name": "αβγδε 项目"
            }
        }
        
        result = generate_tara_excel(
            self.output_path,
            cover_data=unicode_data.get('cover', {}),
            definitions_data={},
            assets_data={},
            attack_trees_data={},
            tara_results_data={}
        )
        
        self.assertTrue(os.path.exists(result))


class TestIntegration(unittest.TestCase):
    """集成测试"""
    
    def setUp(self):
        """设置完整测试数据"""
        self.complete_data = {
            "cover": {
                "report_title": "威胁分析和风险评估报告",
                "report_title_en": "Threat Analysis And Risk Assessment Report",
                "project_name": "——集成测试平台",
                "data_level": "秘密",
                "document_number": "INT-TEST-001",
                "version": "V1.0",
                "author_date": "2025.11",
                "review_date": "2025.12"
            },
            "definitions": {
                "title": "集成测试 TARA分析报告 - 相关定义",
                "functional_description": "这是集成测试的功能描述。车载信息娱乐系统集成多种功能。",
                "assumptions": [
                    {"id": "ASM-01", "description": "系统运行在独立ECU上"},
                    {"id": "ASM-02", "description": "通过CAN网关通信"},
                    {"id": "ASM-03", "description": "具备安全启动功能"}
                ],
                "terminology": [
                    {"abbreviation": "IVI", "english": "In-Vehicle Infotainment", "chinese": "车载信息娱乐系统"},
                    {"abbreviation": "ECU", "english": "Electronic Control Unit", "chinese": "电子控制单元"},
                    {"abbreviation": "CAN", "english": "Controller Area Network", "chinese": "控制器局域网"}
                ]
            },
            "assets": {
                "title": "集成测试 - 资产列表",
                "assets": [
                    {"id": "P001", "name": "SOC", "category": "内部实体", "remarks": "主处理器", "authenticity": True, "availability": True},
                    {"id": "P002", "name": "MCU", "category": "内部实体", "remarks": "微控制器", "authenticity": True, "integrity": True},
                    {"id": "E001", "name": "TBox", "category": "外部实体", "remarks": "远程终端", "authenticity": True}
                ]
            },
            "attack_trees": {
                "title": "集成测试 - 攻击树分析",
                "attack_trees": [
                    {"title": "攻击树1: 远程入侵", "image": ""},
                    {"title": "攻击树2: 物理攻击", "image": ""}
                ]
            },
            "tara_results": {
                "title": "集成测试_TARA分析结果",
                "results": [
                    {
                        "asset_id": "P001", "asset_name": "主机系统",
                        "subdomain1": "系统", "subdomain2": "N/A", "subdomain3": "SOC",
                        "category": "内部实体", "security_attribute": "Authenticity\n真实性",
                        "stride_model": "S欺骗", "threat_scenario": "仿冒攻击",
                        "attack_path": "物理拆解", "wp29_mapping": "4.1",
                        "attack_vector": "本地", "attack_complexity": "低",
                        "privileges_required": "低", "user_interaction": "不需要",
                        "safety_impact": "中等的", "financial_impact": "中等的",
                        "operational_impact": "重大的", "privacy_impact": "可忽略不计的",
                        "security_requirement": "安全启动验证"
                    }
                ]
            }
        }
        self.output_path = tempfile.mktemp(suffix='.xlsx')
    
    def tearDown(self):
        """清理测试文件"""
        if os.path.exists(self.output_path):
            os.remove(self.output_path)
    
    def test_complete_excel_generation(self):
        """测试完整Excel生成"""
        result = generate_tara_excel_from_json(self.output_path, self.complete_data)
        
        self.assertTrue(os.path.exists(result))
        
        wb = load_workbook(result)
        
        # 验证所有Sheet存在
        expected_sheets = [
            "0. 封面 Front Cover",
            "1-相关定义",
            "2-资产列表&数据流图",
            "3-攻击树图",
            "4-TARA分析结果"
        ]
        for sheet_name in expected_sheets:
            self.assertIn(sheet_name, wb.sheetnames)
    
    def test_complete_data_integrity(self):
        """测试完整数据完整性"""
        result = generate_tara_excel_from_json(self.output_path, self.complete_data)
        
        wb = load_workbook(result)
        
        # 检查封面
        cover = wb["0. 封面 Front Cover"]
        self.assertIn("INT-TEST-001", str(cover['F5'].value))
        
        # 检查资产
        assets = wb["2-资产列表&数据流图"]
        asset_found = False
        for row in assets.iter_rows():
            for cell in row:
                if cell.value == "P001":
                    asset_found = True
                    break
        self.assertTrue(asset_found)
        
        # 检查TARA结果
        tara = wb["4-TARA分析结果"]
        self.assertIsNotNone(tara['A6'].value)


if __name__ == '__main__':
    unittest.main(verbosity=2)
