# TARA报告系统 - 问题修复说明

## 最新修复 (v1.3)

### 1. 移除生成预览区域，优化生成成功提示 ✅

**问题描述**: 前端页面一键生成报告中生成预览tab去掉，一键生成报告后，提示生成成功，并提供跳转到报告中心的按钮

**修复方案**:
1. 移除 `GeneratorView.vue` 中右侧的预览区域
2. 页面布局改为单栏居中布局（最大宽度900px）
3. 添加生成成功弹窗，包含：
   - 成功图标和提示信息
   - 统计信息展示（资产数量、威胁场景、高风险项）
   - "前往报告中心"按钮
   - "立即下载"按钮
   - "继续生成"按钮（重置表单）

### 2. 完善报告中心威胁详情弹窗 - 与Excel字段完全一致（含计算值） ✅

**问题描述**: 报告中心预览报告中威胁分析结果详情显示缺失内容，需要与Excel中的字段保持一致，包含所有计算列的计算结果

**修复方案**:
完全重写威胁详情弹窗，采用Excel表格风格布局，包含所有字段和自动计算值：

#### 表格1: 资产信息 (A-G列)
| 列 | 字段名 | 说明 |
|----|-------|------|
| A | Asset ID / 资产ID | 用户输入 |
| B | Asset Name / 资产名称 | 用户输入 |
| C | 子领域一 | 用户输入 |
| D | 子领域二 | 用户输入 |
| E | 子领域三 | 用户输入 |
| F | Category / 分类 | 用户输入 |
| G | Security Attributes / 安全属性 | 用户输入 |

#### 表格2: 威胁分析 (H-K列)
| 列 | 字段名 | 说明 |
|----|-------|------|
| H | STRIDE Model / STRIDE模型 | 用户输入 |
| I | Potential Threat and Damage Scenario / 潜在威胁和损害场景 | 用户输入 |
| J | Attack Path / 攻击路径 | 用户输入 |
| K | WP29威胁映射 | 用户输入 |

#### 表格3: 攻击可行性分析 (L-U列) - 含自动计算
| 列 | 字段名 | 计算公式 |
|----|-------|---------|
| L | 攻击向量-内容 | 用户选择: 网络/邻居/本地/物理 |
| M | 攻击向量-指标值 | **自动计算**: 网络=0.85, 邻居=0.62, 本地=0.55, 物理=0.2 |
| N | 攻击复杂度-内容 | 用户选择: 低/高 |
| O | 攻击复杂度-指标值 | **自动计算**: 低=0.77, 高=0.44 |
| P | 权限要求-等级 | 用户选择: 无/低/高 |
| Q | 权限要求-指标值 | **自动计算**: 无=0.85, 低=0.62, 高=0.27 |
| R | 用户交互-等级 | 用户选择: 不需要/需要 |
| S | 用户交互-指标值 | **自动计算**: 不需要=0.85, 需要=0.62 |
| T | 攻击可行性-计算值 | **自动计算**: `8.22 × M × O × Q × S` |
| U | 攻击可行性-等级 | **自动计算**: ≤1.05=很低, ≤1.99=低, ≤2.99=中, ≤3.99=高, >3.99=很高 |

#### 表格4: 影响分析 (V-AI列) - 含自动计算
| 类别 | 内容列 | 注释列 | 指标值列 |
|------|-------|-------|---------|
| 安全 Safety | V (用户选择) | W (**自动生成**注释) | X (**自动计算**) |
| 经济 Financial | Y (用户选择) | Z (**自动生成**注释) | AA (**自动计算**) |
| 操作 Operational | AB (用户选择) | AC (**自动生成**注释) | AD (**自动计算**) |
| 隐私 Privacy | AE (用户选择) | AF (**自动生成**注释) | AG (**自动计算**) |

**指标值计算**: 可忽略不计的=0, 中等的=1, 重大的=10, 严重的=1000

| 列 | 字段名 | 计算公式 |
|----|-------|---------|
| AH | 影响计算值 | **自动计算**: `X + AA + AD + AG` |
| AI | 影响等级 | **自动计算**: ≥1000=严重的, ≥100=重大的, ≥10=中等的, ≥1=可忽略不计的, <1=无影响 |

#### 表格5: 风险评估与安全需求 (AJ-AN列) - 含自动计算
| 列 | 字段名 | 计算公式 |
|----|-------|---------|
| AJ | 风险等级 (Risk Level) | **自动计算**: 基于影响等级(AI)和攻击可行性等级(U)的矩阵计算 |
| AK | 风险处置决策 | **自动计算**: QM/Low→保留风险, Medium→降低风险, High/Critical→降低/规避/转移风险 |
| AL | 安全目标 | **自动计算**: 保留风险→"/", 其他→"需要定义安全目标" |
| AM | 安全需求 | 用户输入 |
| AN | WP29控制映射 | **自动计算**: T篡改→M10, D拒绝服务→M13, I信息泄露→M11, S欺骗→M23, R抵赖→M24, E权限提升→M16 |

**风险等级矩阵计算规则**:
- QM: 影响=无影响 且 可行性=无
- Low: (影响=无影响 且 可行性≠无) 或 (影响=可忽略 且 可行性∈{很低,低,中}) 或 (影响=中等 且 可行性∈{很低,低}) 或 (影响=重大 且 可行性=很低)
- Medium: (影响=可忽略 且 可行性∈{高,很高}) 或 (影响=中等 且 可行性=中) 或 (影响=重大 且 可行性=低) 或 (影响=严重 且 可行性=很低)
- High: (影响=中等 且 可行性∈{高,很高}) 或 (影响=重大 且 可行性=中) 或 (影响=严重 且 可行性=低)
- Critical: 其他情况

### 3. 添加攻击树图显示 ✅

**问题描述**: 报告中心预览报告没有显示攻击树图

**修复方案**:
1. 在 `ReportDetailView.vue` 中添加攻击树分析区域
2. 使用卡片网格布局展示攻击树
3. 每个攻击树卡片包含：
   - 头部：资产ID和资产名称
   - 主体：攻击树图片（支持点击放大查看）
   - 底部：标题和描述
4. 支持图片悬停效果和点击预览
5. 无图片时显示占位符

## 实现的计算函数

```javascript
// 攻击向量指标值
calcAttackVectorValue(attackVector) // 网络=0.85, 邻居=0.62, 本地=0.55, 物理=0.2

// 攻击复杂度指标值
calcAttackComplexityValue(complexity) // 低=0.77, 高=0.44

// 权限要求指标值
calcPrivilegesValue(privileges) // 无=0.85, 低=0.62, 高=0.27

// 用户交互指标值
calcUserInteractionValue(interaction) // 不需要=0.85, 需要=0.62

// 攻击可行性计算值
calcAttackFeasibilityValue(data) // 8.22 × AV × AC × PR × UI

// 攻击可行性等级
calcAttackFeasibilityLevel(data) // 很低/低/中/高/很高

// 影响指标值
calcImpactValue(impact) // 0/1/10/1000

// 影响总计算值
calcTotalImpactValue(data) // S + F + O + P

// 影响等级
calcImpactLevel(data) // 无影响/可忽略/中等/重大/严重

// 风险等级
calcRiskLevel(data) // QM/Low/Medium/High/Critical

// 风险处置决策
calcRiskTreatment(data) // 保留风险/降低风险/降低风险/规避风险/转移风险

// 安全目标
calcSecurityGoal(data) // / 或 需要定义安全目标

// WP29控制映射
calcWP29ControlMapping(strideModel) // M10/M11/M13/M16/M23/M24
```

## 文件修改清单 (v1.3)

### 前端 (frontend/src/)

1. **views/GeneratorView.vue**
   - 移除右侧预览区域
   - 修改布局为单栏居中
   - 添加 `showSuccessModal` 状态
   - 添加成功弹窗模板和样式
   - 添加 `closeSuccessModal` 和 `resetAndContinue` 方法

2. **views/ReportDetailView.vue**
   - 添加攻击树显示区域和样式
   - 添加 `attackTrees` 计算属性
   - 完全重写威胁详情弹窗为Excel表格风格
   - 添加12个Excel计算函数
   - 添加Excel表格样式和公式说明区域

---

## 修复 (v1.2)

### 1. 攻击树上传功能增强 ✅

**问题描述**: 前端页面不支持上传多张攻击树图及描述，需要修复，并自动替换上传的JSON中attack_trees相关字段

**修复方案**:
1. 在 `GeneratorView.vue` 中新增完整的攻击树上传区域
2. 支持动态添加/删除多个攻击树
3. 每个攻击树支持以下字段：
   - 资产ID
   - 资产名称
   - 攻击树标题
   - 描述
   - 图片上传
4. 上传时自动读取JSON文件，将攻击树数据合并到 `attack_trees.attack_trees` 字段
5. 图片通过 `uploadAndGenerate` API批量上传

**使用方式**:
- 点击"添加攻击树"按钮添加新的攻击树条目
- 为每个攻击树填写相关信息并上传图片
- 生成报告时自动将攻击树数据合并到JSON中

### 2. 相关项假设显示修复 ✅

**问题描述**: 前端预览报告不支持查看相关定义中的相关项假设

**修复方案**:
1. 更新 `ReportPreview.vue` 中的假设显示逻辑
2. 支持多种数据格式：
   - 字符串数组格式: `["假设1", "假设2"]`
   - 对象数组格式: `[{id: "ASM-001", description: "描述", source: "来源", rationale: "依据"}]`
3. 自动生成假设编号（如 ASM-001, ASM-002）
4. 支持显示来源和依据字段（如果数据中存在）

### 3. 威胁分析详情查看功能 ✅

**问题描述**: 前端预览报告中威胁分析结果，选择某一条点击可以查看详情威胁分析、影响分析、风险评估等所有字段

**修复方案**:
1. 在 `ReportPreview.vue` 中添加威胁详情弹窗
2. 表格行支持点击触发详情弹窗
3. 详情弹窗包含以下信息分组：
   - **基本信息**: 资产ID、资产名称、威胁ID、STRIDE模型
   - **威胁分析**: 威胁场景、损害场景、攻击路径
   - **攻击可行性分析**: 攻击向量(AV)、攻击复杂度(AC)、所需权限(PR)、用户交互(UI)等
   - **影响分析**: 安全影响(S)、财务影响(F)、运营影响(O)、隐私影响(P)
   - **风险评估**: 风险值、风险等级、残余风险、风险处置
   - **安全措施**: 安全措施、有效性、安全目标、网络安全需求
   - **其他信息**: 备注、验证方法、状态
4. 添加表格行点击提示
5. 添加"详情"操作按钮

## 修复 (v1.1)

### 1. 图片上传报错 Network Error ✅

**问题描述**: 上传图片时报错 "图片上传失败: Network Error"

**根本原因**:
- 前端 ImageUpload 组件发出的事件名是 `images-changed`，但 GenerateView 监听的是 `@change`
- 字段名称不匹配：组件使用 `item_boundary`，但后端期望 `item_boundary_image`
- 请求超时时间太短

**修复方案**:
1. 重写 `ImageUpload.vue` 组件，统一事件名为 `change`
2. 统一字段命名为 `item_boundary_image` 等
3. 增加文件大小验证（最大10MB）
4. 增加超时时间到2分钟
5. 更新 vite.config.js 的代理超时设置

### 2. 支持多张攻击树图上传 ✅

**新功能**: 现在支持上传多张攻击树图片

**实现方式**:
- 在 ImageUpload 组件中新增攻击树图片上传区域
- 支持一次选择多张图片
- 支持动态添加和删除
- 后端 `/api/upload/batch` 端点新增 `attack_tree_images` 参数（支持多文件）
- 自动将攻击树图片关联到 JSON 数据的 `attack_trees.attack_trees` 数组

**使用方式**:
```
前端: formData.append('attack_tree_images', file1)
      formData.append('attack_tree_images', file2)
      ...
后端: attack_tree_images: List[UploadFile]
```

## 修复 (v1.0)

### 1. 图片与JSON关联问题

**修复方案**:
- 新增 `/api/upload/batch` 端点，支持同时上传JSON文件和图片文件
- 图片上传后自动保存到 `uploads/images/` 目录
- 图片路径自动关联到JSON数据的对应字段

### 2. 前端预览缺少攻击树展示

**修复方案**:
- 更新 `ReportPreview.vue` 组件，添加攻击树展示区域
- 添加图片预览组件，支持放大查看
- 添加功能描述、假设条目、术语表等展示

### 3. TARA分析结果显示不完整

**修复方案**:
更新TARA分析结果表格，显示完整字段

## 文件修改清单 (v1.2)

### 前端 (frontend/src/)

1. **views/GeneratorView.vue**
   - 新增攻击树上传区域（模板和样式）
   - 新增攻击树相关状态变量
   - 新增攻击树相关方法：`addAttackTree`, `removeAttackTree`, `handleAttackTreeSelect`, `handleAttackTreeDrop`, `triggerAttackTreeUpload`
   - 更新 `generateReport` 函数，支持攻击树数据合并到JSON

2. **components/ReportPreview.vue**
   - 更新假设显示逻辑，支持多种数据格式
   - 新增 `assumptionsList` 计算属性
   - 新增威胁详情弹窗
   - 新增 `showThreatDetail`, `handleThreatRowClick`, `hasOtherInfo` 方法
   - 添加点击行提示和详情按钮

3. **api/index.js**
   - 更新 `uploadImage` 函数返回格式
   - 新增 `uploadAndGenerate` 函数

## 文件修改清单 (v1.1)

### 后端 (backend/tara_api/)

1. **main.py**
   - `upload_batch` 端点新增 `attack_tree_images: List[UploadFile]` 参数
   - 添加攻击树图片处理逻辑
   - 自动创建攻击树条目

### 前端 (frontend/src/)

1. **components/ImageUpload.vue** (完全重写)
   - 修复事件名称为 `change`
   - 修复字段名称匹配后端
   - 新增攻击树图片上传功能
   - 添加文件大小验证（10MB限制）
   - 支持多图上传

2. **views/GenerateView.vue**
   - 更新 `handleGenerate` 函数提取攻击树图片

3. **stores/report.ts**
   - 更新 `generateReport` 函数参数类型

4. **api/index.ts**
   - 更新 `uploadAndGenerate` 函数支持攻击树图片数组
   - 增加超时时间到2分钟
   - 增加 `maxContentLength` 和 `maxBodyLength` 设置

5. **vite.config.js**
   - 增加代理超时设置

## 图片类型说明

| 字段名 | 说明 | 支持数量 |
|--------|------|----------|
| item_boundary_image | 项目边界图 | 1张 |
| system_architecture_image | 系统架构图 | 1张 |
| software_architecture_image | 软件架构图 | 1张 |
| dataflow_image | 数据流图 | 1张 |
| attack_tree_images | 攻击树图 | 多张 |

## 使用说明

### 启动后端
```bash
cd backend
pip install -e .
python -m uvicorn tara_api.main:app --host 0.0.0.0 --port 8000
```

### 启动前端
```bash
cd frontend
npm install
npm run dev
```

### API端点说明

| 端点 | 方法 | 说明 |
|------|------|------|
| `/api/upload/batch` | POST | 批量上传JSON和图片（包括多张攻击树图） |
| `/api/reports` | GET | 获取报告列表 |
| `/api/reports/{id}/preview` | GET | 获取预览数据 |
| `/api/reports/{id}/download` | GET | 下载报告 |
| `/api/images/{id}` | GET | 获取图片 |

### FormData 字段

批量上传时使用的 FormData 字段：
- `json_file`: JSON数据文件（必需）
- `item_boundary_image`: 项目边界图（可选，单个文件）
- `system_architecture_image`: 系统架构图（可选，单个文件）
- `software_architecture_image`: 软件架构图（可选，单个文件）
- `dataflow_image`: 数据流图（可选，单个文件）
- `attack_tree_images`: 攻击树图（可选，可多次添加同名字段实现多文件上传）

## 文件大小限制

- 单个图片最大: 10MB
- 支持格式: PNG, JPG, JPEG, GIF, BMP
- 请求超时: 2分钟

## 攻击树数据格式

上传的攻击树数据会自动合并到JSON的 `attack_trees.attack_trees` 字段中，格式如下：

```json
{
  "attack_trees": {
    "attack_trees": [
      {
        "asset_id": "AT001",
        "asset_name": "车载控制系统",
        "title": "针对车载控制系统的攻击树分析",
        "description": "攻击树描述内容...",
        "attack_tree_image": ""
      }
    ]
  }
}
```

图片路径会在后端处理时自动填充。
