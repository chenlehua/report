import axios from 'axios'
import type { ReportInfo, PreviewData, ApiResponse } from '@/types'

const api = axios.create({
  baseURL: '/api',
  timeout: 60000,
  headers: {
    'Content-Type': 'application/json'
  }
})

// 获取报告列表
export async function getReports(page = 1, limit = 10): Promise<{ items: ReportInfo[]; total: number }> {
  const response = await api.get('/reports', { params: { page, limit } })
  // 适应后端返回格式 { success, reports, total }
  const data = response.data
  return {
    items: data.reports || [],
    total: data.total || 0
  }
}

// 生成报告 (JSON数据)
export async function generateReport(data: any): Promise<ReportInfo> {
  const response = await api.post('/reports/generate', data)
  return response.data
}

// 上传JSON文件和图片批量生成
export async function uploadAndGenerate(
  jsonFile: File,
  images?: {
    item_boundary?: File
    system_architecture?: File
    software_architecture?: File
    dataflow?: File
  }
): Promise<{ success: boolean; message: string; report_info: ReportInfo }> {
  const formData = new FormData()
  formData.append('json_file', jsonFile)
  
  if (images?.item_boundary) {
    formData.append('item_boundary_image', images.item_boundary)
  }
  if (images?.system_architecture) {
    formData.append('system_architecture_image', images.system_architecture)
  }
  if (images?.software_architecture) {
    formData.append('software_architecture_image', images.software_architecture)
  }
  if (images?.dataflow) {
    formData.append('dataflow_image', images.dataflow)
  }
  
  const response = await api.post('/upload/batch', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  })
  return response.data
}

// 获取报告预览数据
export async function getReportPreview(reportId: string): Promise<PreviewData> {
  const response = await api.get(`/reports/${reportId}/preview`)
  return response.data
}

// 下载报告
export async function downloadReport(reportId: string): Promise<Blob> {
  const response = await api.get(`/reports/${reportId}/download`, {
    responseType: 'blob'
  })
  return response.data
}

// 删除报告
export async function deleteReport(reportId: string): Promise<void> {
  await api.delete(`/reports/${reportId}`)
}

// 上传单个图片
export async function uploadImage(file: File, type: string): Promise<{ filename: string; url: string }> {
  const formData = new FormData()
  formData.append('file', file)
  formData.append('type', type)
  
  const response = await api.post('/images/upload', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  })
  return response.data
}

// 获取图片URL
export function getImageUrl(filename: string): string {
  return `/api/images/${filename}`
}

export default api
