<template>
  <div class="image-upload-grid">
    <div 
      v-for="slot in imageSlots" 
      :key="slot.type"
      class="image-slot"
      :class="{ 'has-image': images[slot.type] }"
    >
      <input 
        :ref="el => (inputRefs[slot.type] = el as HTMLInputElement)"
        type="file" 
        accept="image/*"
        @change="e => handleImageSelect(e, slot.type)"
        style="display: none"
      />
      
      <div v-if="!images[slot.type]" class="slot-placeholder" @click="triggerSelect(slot.type)">
        <el-icon :size="24"><Picture /></el-icon>
        <span>{{ slot.label }}</span>
        <span class="optional">可选</span>
      </div>
      
      <div v-else class="slot-preview">
        <img :src="previews[slot.type]" :alt="slot.label" />
        <div class="preview-overlay">
          <el-button type="primary" circle size="small" @click="triggerSelect(slot.type)">
            <el-icon><RefreshRight /></el-icon>
          </el-button>
          <el-button type="danger" circle size="small" @click="clearImage(slot.type)">
            <el-icon><Delete /></el-icon>
          </el-button>
        </div>
        <span class="slot-label">{{ slot.label }}</span>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive } from 'vue'
import { Picture, RefreshRight, Delete } from '@element-plus/icons-vue'

type ImageType = 'item_boundary' | 'system_architecture' | 'software_architecture' | 'dataflow'

const emit = defineEmits<{
  (e: 'images-changed', images: Record<ImageType, File | undefined>): void
}>()

const imageSlots: Array<{ type: ImageType; label: string }> = [
  { type: 'item_boundary', label: '项目边界图' },
  { type: 'system_architecture', label: '系统架构图' },
  { type: 'software_architecture', label: '软件架构图' },
  { type: 'dataflow', label: '数据流图' }
]

const inputRefs = reactive<Record<string, HTMLInputElement | null>>({})
const images = reactive<Record<ImageType, File | undefined>>({
  item_boundary: undefined,
  system_architecture: undefined,
  software_architecture: undefined,
  dataflow: undefined
})
const previews = reactive<Record<ImageType, string>>({
  item_boundary: '',
  system_architecture: '',
  software_architecture: '',
  dataflow: ''
})

function triggerSelect(type: ImageType) {
  inputRefs[type]?.click()
}

function handleImageSelect(event: Event, type: ImageType) {
  const input = event.target as HTMLInputElement
  if (input.files && input.files[0]) {
    const file = input.files[0]
    images[type] = file
    
    // 生成预览URL
    const reader = new FileReader()
    reader.onload = (e) => {
      previews[type] = e.target?.result as string
    }
    reader.readAsDataURL(file)
    
    emitChange()
  }
}

function clearImage(type: ImageType) {
  images[type] = undefined
  previews[type] = ''
  if (inputRefs[type]) {
    inputRefs[type]!.value = ''
  }
  emitChange()
}

function emitChange() {
  emit('images-changed', { ...images })
}

// 暴露方法供父组件使用
defineExpose({
  getImages: () => ({ ...images }),
  clearAll: () => {
    Object.keys(images).forEach(key => {
      images[key as ImageType] = undefined
      previews[key as ImageType] = ''
    })
  }
})
</script>

<style scoped lang="scss">
.image-upload-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 16px;
}

.image-slot {
  aspect-ratio: 16 / 9;
  border: 2px dashed rgba(255, 255, 255, 0.1);
  border-radius: 8px;
  overflow: hidden;
  transition: all 0.3s ease;
  
  &.has-image {
    border-style: solid;
    border-color: transparent;
  }
  
  &:hover {
    border-color: rgba(255, 255, 255, 0.2);
  }
}

.slot-placeholder {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 8px;
  cursor: pointer;
  background: rgba(255, 255, 255, 0.02);
  transition: background 0.3s ease;
  
  &:hover {
    background: rgba(255, 255, 255, 0.05);
  }
  
  .el-icon {
    color: rgba(255, 255, 255, 0.3);
  }
  
  span {
    font-size: 13px;
    color: rgba(255, 255, 255, 0.6);
  }
  
  .optional {
    font-size: 11px;
    color: rgba(255, 255, 255, 0.3);
  }
}

.slot-preview {
  position: relative;
  width: 100%;
  height: 100%;
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
  
  .preview-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.6);
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 12px;
    opacity: 0;
    transition: opacity 0.3s ease;
  }
  
  &:hover .preview-overlay {
    opacity: 1;
  }
  
  .slot-label {
    position: absolute;
    bottom: 8px;
    left: 8px;
    font-size: 12px;
    color: white;
    background: rgba(0, 0, 0, 0.6);
    padding: 4px 8px;
    border-radius: 4px;
  }
}
</style>
