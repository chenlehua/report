<template>
  <div class="generator-page animate-fadeIn">
    <div class="page-header">
      <h1>一键生成TARA报告</h1>
      <p class="page-desc">上传JSON参数文件和相关图片，快速生成专业的威胁分析与风险评估报告</p>
    </div>

    <div class="generator-content">
      <!-- 左侧：上传区域 -->
      <div class="upload-section">
        <!-- JSON文件上传 -->
        <div class="card upload-card">
          <h3>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
              <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/>
              <path d="M14 2v6h6"/>
            </svg>
            上传JSON数据文件
          </h3>
          
          <div 
            class="upload-zone"
            :class="{ dragover: isDragging }"
            @drop.prevent="handleJsonDrop"
            @dragover.prevent="isDragging = true"
            @dragleave="isDragging = false"
            @click="$refs.jsonInput.click()"
          >
            <input 
              ref="jsonInput"
              type="file" 
              accept=".json"
              style="display: none"
              @change="handleJsonSelect"
            >
            <svg class="upload-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
              <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/>
              <polyline points="17,8 12,3 7,8"/>
              <line x1="12" y1="3" x2="12" y2="15"/>
            </svg>
            <p v-if="!jsonFile">点击或拖拽上传JSON文件</p>
            <p v-else class="file-selected">{{ jsonFile.name }}</p>
            <span class="upload-hint">支持 .json 格式</span>
          </div>

          <div v-if="jsonFile" class="file-item">
            <div class="file-icon json">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/>
                <path d="M14 2v6h6"/>
              </svg>
            </div>
            <div class="file-info">
              <div class="file-name">{{ jsonFile.name }}</div>
              <div class="file-size">{{ formatFileSize(jsonFile.size) }}</div>
            </div>
            <button class="btn-remove" @click="removeJsonFile">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                <line x1="18" y1="6" x2="6" y2="18"/>
                <line x1="6" y1="6" x2="18" y2="18"/>
              </svg>
            </button>
          </div>
        </div>

        <!-- 图片上传 -->
        <div class="card upload-card">
          <h3>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
              <rect x="3" y="3" width="18" height="18" rx="2"/>
              <circle cx="8.5" cy="8.5" r="1.5"/>
              <path d="M21 15l-5-5L5 21"/>
            </svg>
            上传相关图片（可选）
          </h3>

          <div class="image-upload-grid">
            <ImageUploader
              v-for="item in imageTypes"
              :key="item.type"
              :label="item.label"
              :image-type="item.type"
              :uploaded-image="uploadedImages[item.type]"
              @upload="handleImageUpload"
              @remove="removeImage"
            />
          </div>
        </div>

        <!-- 生成按钮 -->
        <div class="generate-section">
          <button 
            class="btn btn-primary generate-btn"
            :disabled="!jsonFile || isGenerating"
            @click="generateReport"
          >
            <svg v-if="!isGenerating" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
              <path d="M12 3l1.912 5.813a2 2 0 001.275 1.275L21 12l-5.813 1.912a2 2 0 00-1.275 1.275L12 21l-1.912-5.813a2 2 0 00-1.275-1.275L3 12l5.813-1.912a2 2 0 001.275-1.275L12 3z"/>
            </svg>
            <svg v-else class="animate-spin" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
              <circle cx="12" cy="12" r="10" stroke-opacity="0.25"/>
              <path d="M12 2a10 10 0 0110 10" stroke-linecap="round"/>
            </svg>
            {{ isGenerating ? '正在生成...' : '一键生成TARA报告' }}
          </button>
        </div>
      </div>

      <!-- 右侧：预览区域 -->
      <div class="preview-section">
        <div class="card preview-card">
          <h3>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
              <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
              <circle cx="12" cy="12" r="3"/>
            </svg>
            生成预览
          </h3>

          <!-- 无数据状态 -->
          <div v-if="!generatedReport" class="preview-empty">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
              <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/>
              <path d="M14 2v6h6"/>
              <path d="M12 18v-6"/>
              <path d="M9 15l3-3 3 3"/>
            </svg>
            <p>上传文件并生成报告后，预览将显示在此处</p>
          </div>

          <!-- 预览内容 -->
          <div v-else class="preview-content">
            <div class="preview-stats">
              <div class="stat-card">
                <div class="stat-icon blue">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <rect x="2" y="3" width="20" height="14" rx="2"/>
                    <path d="M8 21h8"/>
                    <path d="M12 17v4"/>
                  </svg>
                </div>
                <div class="stat-info">
                  <span class="stat-value">{{ generatedReport.statistics?.assets_count || 0 }}</span>
                  <span class="stat-label">资产数量</span>
                </div>
              </div>

              <div class="stat-card">
                <div class="stat-icon yellow">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/>
                    <line x1="12" y1="9" x2="12" y2="13"/>
                    <line x1="12" y1="17" x2="12.01" y2="17"/>
                  </svg>
                </div>
                <div class="stat-info">
                  <span class="stat-value">{{ generatedReport.statistics?.threats_count || 0 }}</span>
                  <span class="stat-label">威胁场景</span>
                </div>
              </div>

              <div class="stat-card">
                <div class="stat-icon red">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"/>
                    <path d="m14.5 9-5 5"/>
                    <path d="m9.5 9 5 5"/>
                  </svg>
                </div>
                <div class="stat-info">
                  <span class="stat-value">{{ generatedReport.statistics?.high_risk_count || 0 }}</span>
                  <span class="stat-label">高风险项</span>
                </div>
              </div>
            </div>

            <!-- 图片预览 -->
            <div v-if="hasImages" class="images-preview">
              <h4>架构图预览</h4>
              <div class="images-grid">
                <div 
                  v-for="(url, type) in previewImages" 
                  :key="type"
                  class="image-preview-item"
                  @click="showImageModal(url, getImageLabel(type))"
                >
                  <img :src="url" :alt="getImageLabel(type)">
                  <div class="image-label">{{ getImageLabel(type) }}</div>
                </div>
              </div>
            </div>

            <!-- 操作按钮 -->
            <div class="preview-actions">
              <a 
                :href="downloadUrl" 
                class="btn btn-primary"
                download
              >
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                  <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/>
                  <polyline points="7,10 12,15 17,10"/>
                  <line x1="12" y1="15" x2="12" y2="3"/>
                </svg>
                下载报告
              </a>
              <router-link 
                :to="`/reports/${generatedReport.report_id}`" 
                class="btn btn-secondary"
              >
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                  <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                  <circle cx="12" cy="12" r="3"/>
                </svg>
                查看详情
              </router-link>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 图片预览模态框 -->
    <div v-if="imageModal.show" class="modal-overlay" @click="closeImageModal">
      <div class="modal-content image-modal" @click.stop>
        <div class="modal-header">
          <h3>{{ imageModal.title }}</h3>
          <button class="btn-close" @click="closeImageModal">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
              <line x1="18" y1="6" x2="6" y2="18"/>
              <line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
          </button>
        </div>
        <div class="modal-body">
          <img :src="imageModal.url" :alt="imageModal.title">
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { uploadImage, generateReport as generateReportApi, getDownloadUrl } from '@/api'
import ImageUploader from '@/components/ImageUploader.vue'

// 状态
const isDragging = ref(false)
const isGenerating = ref(false)
const jsonFile = ref(null)
const uploadedImages = ref({})
const generatedReport = ref(null)

const imageModal = ref({
  show: false,
  url: '',
  title: ''
})

// 图片类型配置
const imageTypes = [
  { type: 'item_boundary', label: '项目边界图' },
  { type: 'system_architecture', label: '系统架构图' },
  { type: 'software_architecture', label: '软件架构图' },
  { type: 'dataflow', label: '数据流图' }
]

// 计算属性
const downloadUrl = computed(() => {
  return generatedReport.value ? getDownloadUrl(generatedReport.value.report_id) : ''
})

const previewImages = computed(() => {
  if (!generatedReport.value?.preview_data?.images) return {}
  const images = generatedReport.value.preview_data.images
  return Object.fromEntries(
    Object.entries(images).filter(([_, url]) => url)
  )
})

const hasImages = computed(() => {
  return Object.keys(previewImages.value).length > 0
})

// 方法
function formatFileSize(bytes) {
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB'
}

function handleJsonDrop(e) {
  isDragging.value = false
  const files = e.dataTransfer.files
  if (files.length > 0 && files[0].name.endsWith('.json')) {
    jsonFile.value = files[0]
  }
}

function handleJsonSelect(e) {
  const files = e.target.files
  if (files.length > 0) {
    jsonFile.value = files[0]
  }
}

function removeJsonFile() {
  jsonFile.value = null
}

async function handleImageUpload({ file, imageType }) {
  try {
    const result = await uploadImage(file, imageType)
    if (result.success) {
      uploadedImages.value[imageType] = {
        id: result.image_id,
        url: result.image_url,
        file: file
      }
    }
  } catch (error) {
    alert('图片上传失败: ' + error.message)
  }
}

function removeImage(imageType) {
  delete uploadedImages.value[imageType]
}

function getImageLabel(type) {
  const item = imageTypes.find(i => i.type === type)
  return item ? item.label : type
}

async function generateReport() {
  if (!jsonFile.value) return
  
  isGenerating.value = true
  
  try {
    const params = {
      jsonFile: jsonFile.value,
      itemBoundaryImage: uploadedImages.value.item_boundary?.id,
      systemArchitectureImage: uploadedImages.value.system_architecture?.id,
      softwareArchitectureImage: uploadedImages.value.software_architecture?.id,
      dataflowImage: uploadedImages.value.dataflow?.id
    }
    
    const result = await generateReportApi(params)
    
    if (result.success) {
      generatedReport.value = result
    } else {
      alert('生成失败: ' + result.message)
    }
  } catch (error) {
    alert('生成失败: ' + error.message)
  } finally {
    isGenerating.value = false
  }
}

function showImageModal(url, title) {
  imageModal.value = { show: true, url, title }
}

function closeImageModal() {
  imageModal.value = { show: false, url: '', title: '' }
}
</script>

<style scoped>
.generator-page {
  max-width: 1400px;
  margin: 0 auto;
}

.page-header {
  margin-bottom: 32px;
}

.page-header h1 {
  font-size: 28px;
  font-weight: 700;
  margin-bottom: 8px;
}

.page-desc {
  color: var(--text-muted);
  font-size: 15px;
}

.generator-content {
  display: grid;
  grid-template-columns: 1fr 400px;
  gap: 24px;
}

.upload-section {
  display: flex;
  flex-direction: column;
  gap: 24px;
}

.upload-card h3,
.preview-card h3 {
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 16px;
  font-weight: 600;
  margin-bottom: 20px;
  padding-bottom: 16px;
  border-bottom: 1px solid var(--border-color);
}

.upload-card h3 svg,
.preview-card h3 svg {
  width: 20px;
  height: 20px;
  color: var(--brand-blue);
}

.upload-zone {
  border: 2px dashed var(--border-color);
  border-radius: 16px;
  padding: 48px 24px;
  text-align: center;
  cursor: pointer;
  transition: all 0.3s ease;
  margin-bottom: 16px;
}

.upload-zone:hover,
.upload-zone.dragover {
  border-color: var(--brand-blue);
  background: rgba(59,130,246,0.05);
}

.upload-icon {
  width: 48px;
  height: 48px;
  color: var(--text-muted);
  margin-bottom: 16px;
}

.upload-zone p {
  color: var(--text-secondary);
  margin-bottom: 8px;
}

.upload-zone .file-selected {
  color: var(--brand-blue);
  font-weight: 500;
}

.upload-hint {
  font-size: 12px;
  color: var(--text-muted);
}

.file-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 16px;
  background: var(--bg-tertiary);
  border-radius: 12px;
}

.file-icon {
  width: 44px;
  height: 44px;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.file-icon.json {
  background: rgba(245,158,11,0.15);
  color: #F59E0B;
}

.file-icon svg {
  width: 22px;
  height: 22px;
}

.file-info {
  flex: 1;
}

.file-name {
  font-weight: 500;
  margin-bottom: 2px;
}

.file-size {
  font-size: 12px;
  color: var(--text-muted);
}

.btn-remove {
  width: 32px;
  height: 32px;
  border-radius: 8px;
  border: none;
  background: transparent;
  color: var(--text-muted);
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.2s;
}

.btn-remove:hover {
  background: rgba(239,68,68,0.1);
  color: var(--danger);
}

.btn-remove svg {
  width: 18px;
  height: 18px;
}

.image-upload-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 16px;
}

.generate-section {
  display: flex;
  justify-content: center;
  padding: 24px;
  background: var(--bg-card);
  border-radius: 16px;
  border: 1px solid var(--border-color);
}

.generate-btn {
  padding: 18px 48px;
  font-size: 16px;
}

.generate-btn svg {
  width: 22px;
  height: 22px;
}

/* Preview Section */
.preview-section {
  position: sticky;
  top: 32px;
  height: fit-content;
}

.preview-card {
  padding: 24px;
}

.preview-empty {
  text-align: center;
  padding: 48px 24px;
  color: var(--text-muted);
}

.preview-empty svg {
  width: 64px;
  height: 64px;
  margin-bottom: 16px;
  opacity: 0.5;
}

.preview-content {
  display: flex;
  flex-direction: column;
  gap: 24px;
}

.preview-stats {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.stat-card {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 16px;
  background: var(--bg-tertiary);
  border-radius: 12px;
}

.stat-icon {
  width: 44px;
  height: 44px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 10px;
}

.stat-icon svg {
  width: 22px;
  height: 22px;
}

.stat-icon.blue { background: rgba(99,102,241,0.1); color: #6366f1; }
.stat-icon.yellow { background: rgba(245,158,11,0.1); color: #f59e0b; }
.stat-icon.red { background: rgba(239,68,68,0.1); color: #ef4444; }

.stat-info {
  display: flex;
  flex-direction: column;
}

.stat-value {
  font-size: 24px;
  font-weight: 700;
}

.stat-label {
  font-size: 12px;
  color: var(--text-muted);
}

.images-preview h4 {
  font-size: 14px;
  font-weight: 600;
  margin-bottom: 12px;
  color: var(--text-secondary);
}

.images-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 12px;
}

.image-preview-item {
  position: relative;
  border-radius: 10px;
  overflow: hidden;
  cursor: pointer;
  aspect-ratio: 16/10;
  background: var(--bg-tertiary);
}

.image-preview-item img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.3s;
}

.image-preview-item:hover img {
  transform: scale(1.05);
}

.image-label {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  padding: 8px;
  background: linear-gradient(transparent, rgba(0,0,0,0.8));
  font-size: 11px;
  color: white;
}

.preview-actions {
  display: flex;
  gap: 12px;
}

.preview-actions .btn {
  flex: 1;
  justify-content: center;
}

.preview-actions .btn svg {
  width: 18px;
  height: 18px;
}

/* Image Modal */
.image-modal {
  width: auto;
  max-width: 90vw;
  max-height: 90vh;
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 20px;
  border-bottom: 1px solid var(--border-color);
}

.modal-header h3 {
  font-size: 16px;
  font-weight: 600;
}

.btn-close {
  width: 32px;
  height: 32px;
  border-radius: 8px;
  border: none;
  background: transparent;
  color: var(--text-muted);
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
}

.btn-close:hover {
  background: var(--bg-hover);
  color: var(--text-primary);
}

.btn-close svg {
  width: 20px;
  height: 20px;
}

.modal-body {
  padding: 20px;
}

.modal-body img {
  max-width: 100%;
  max-height: 70vh;
  border-radius: 8px;
}

@media (max-width: 1200px) {
  .generator-content {
    grid-template-columns: 1fr;
  }
  
  .preview-section {
    position: static;
  }
  
  .image-upload-grid {
    grid-template-columns: 1fr;
  }
}
</style>
