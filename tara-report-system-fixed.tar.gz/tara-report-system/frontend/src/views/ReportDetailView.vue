<template>
  <div class="report-detail-page animate-fadeIn">
    <!-- 加载状态 -->
    <div v-if="isLoading" class="loading-state">
      <svg class="animate-spin" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
        <circle cx="12" cy="12" r="10" stroke-opacity="0.25"/>
        <path d="M12 2a10 10 0 0110 10" stroke-linecap="round"/>
      </svg>
      <span>加载中...</span>
    </div>

    <template v-else-if="report">
      <!-- 页面头部 -->
      <div class="detail-header">
        <div class="header-left">
          <button class="btn-back" @click="$router.back()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
              <polyline points="15 18 9 12 15 6"/>
            </svg>
            返回
          </button>
          <div class="title-section">
            <h1>{{ report.name }}</h1>
            <div class="header-meta">
              <span class="badge badge-success">已完成</span>
              <span class="meta-item">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                  <circle cx="12" cy="12" r="10"/>
                  <polyline points="12 6 12 12 16 14"/>
                </svg>
                {{ formatDate(report.created_at) }}
              </span>
            </div>
          </div>
        </div>
        <div class="header-actions">
          <a :href="downloadUrl" class="btn btn-primary" download>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
              <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/>
              <polyline points="7,10 12,15 17,10"/>
              <line x1="12" y1="15" x2="12" y2="3"/>
            </svg>
            下载报告
          </a>
        </div>
      </div>

      <!-- 统计卡片 -->
      <div class="stats-grid">
        <div class="stat-card">
          <div class="stat-icon blue">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <rect x="2" y="3" width="20" height="14" rx="2"/>
              <path d="M8 21h8"/>
              <path d="M12 17v4"/>
            </svg>
          </div>
          <div class="stat-info">
            <span class="stat-value">{{ report.statistics?.assets_count || 0 }}</span>
            <span class="stat-label">资产数量</span>
          </div>
        </div>

        <div class="stat-card">
          <div class="stat-icon yellow">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/>
              <line x1="12" y1="9" x2="12" y2="13"/>
              <line x1="12" y1="17" x2="12.01" y2="17"/>
            </svg>
          </div>
          <div class="stat-info">
            <span class="stat-value">{{ report.statistics?.threats_count || 0 }}</span>
            <span class="stat-label">威胁场景</span>
          </div>
        </div>

        <div class="stat-card">
          <div class="stat-icon red">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"/>
              <path d="m14.5 9-5 5"/>
              <path d="m9.5 9 5 5"/>
            </svg>
          </div>
          <div class="stat-info">
            <span class="stat-value">{{ report.statistics?.high_risk_count || 0 }}</span>
            <span class="stat-label">高风险项</span>
          </div>
        </div>

        <div class="stat-card">
          <div class="stat-icon green">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10"/>
              <path d="m9 12 2 2 4-4"/>
            </svg>
          </div>
          <div class="stat-info">
            <span class="stat-value">{{ report.statistics?.measures_count || 0 }}</span>
            <span class="stat-label">安全措施</span>
          </div>
        </div>
      </div>

      <!-- 项目信息 -->
      <div class="section-card">
        <h2>项目信息</h2>
        <div class="section-content">
          <p class="section-desc">本报告基于 ISO/SAE 21434 标准，对目标系统进行了全面的威胁分析和风险评估 (TARA)。</p>
          <div class="info-grid">
            <div class="info-item">
              <span class="info-label">项目名称</span>
              <span class="info-value">{{ report.project_name }}</span>
            </div>
            <div class="info-item">
              <span class="info-label">报告标题</span>
              <span class="info-value">{{ report.cover?.report_title || report.name }}</span>
            </div>
            <div class="info-item">
              <span class="info-label">文档编号</span>
              <span class="info-value">{{ report.cover?.document_number || '-' }}</span>
            </div>
            <div class="info-item">
              <span class="info-label">版本</span>
              <span class="info-value">{{ report.cover?.version || 'V1.0' }}</span>
            </div>
            <div class="info-item">
              <span class="info-label">数据等级</span>
              <span class="info-value">{{ report.cover?.data_level || '秘密' }}</span>
            </div>
            <div class="info-item">
              <span class="info-label">生成时间</span>
              <span class="info-value">{{ formatDate(report.created_at) }}</span>
            </div>
          </div>
        </div>
      </div>

      <!-- 架构图预览 -->
      <div v-if="hasImages" class="section-card">
        <h2>架构图</h2>
        <div class="section-content">
          <div class="images-grid">
            <div 
              v-if="report.definitions?.item_boundary_image"
              class="image-card"
              @click="showImageModal(report.definitions.item_boundary_image, '项目边界图')"
            >
              <img :src="getImageSrc(report.definitions.item_boundary_image)" alt="项目边界图">
              <div class="image-title">项目边界图</div>
            </div>
            <div 
              v-if="report.definitions?.system_architecture_image"
              class="image-card"
              @click="showImageModal(report.definitions.system_architecture_image, '系统架构图')"
            >
              <img :src="getImageSrc(report.definitions.system_architecture_image)" alt="系统架构图">
              <div class="image-title">系统架构图</div>
            </div>
            <div 
              v-if="report.definitions?.software_architecture_image"
              class="image-card"
              @click="showImageModal(report.definitions.software_architecture_image, '软件架构图')"
            >
              <img :src="getImageSrc(report.definitions.software_architecture_image)" alt="软件架构图">
              <div class="image-title">软件架构图</div>
            </div>
            <div 
              v-if="report.assets?.dataflow_image"
              class="image-card"
              @click="showImageModal(report.assets.dataflow_image, '数据流图')"
            >
              <img :src="getImageSrc(report.assets.dataflow_image)" alt="数据流图">
              <div class="image-title">数据流图</div>
            </div>
          </div>
        </div>
      </div>

      <!-- 功能描述 -->
      <div v-if="report.definitions?.functional_description" class="section-card">
        <h2>功能描述</h2>
        <div class="section-content">
          <p class="functional-desc">{{ report.definitions.functional_description }}</p>
        </div>
      </div>

      <!-- 资产列表 -->
      <div v-if="assets.length > 0" class="section-card">
        <h2>资产清单 ({{ assets.length }})</h2>
        <div class="section-content">
          <table class="data-table">
            <thead>
              <tr>
                <th>资产ID</th>
                <th>资产名称</th>
                <th>分类</th>
                <th>备注</th>
                <th>安全属性</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="asset in assets" :key="asset.id">
                <td>{{ asset.id }}</td>
                <td>{{ asset.name }}</td>
                <td>{{ asset.category }}</td>
                <td>{{ asset.remarks }}</td>
                <td>
                  <span v-if="asset.authenticity" class="attr-tag">真实性</span>
                  <span v-if="asset.integrity" class="attr-tag">完整性</span>
                  <span v-if="asset.availability" class="attr-tag">可用性</span>
                  <span v-if="asset.confidentiality" class="attr-tag">机密性</span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <!-- TARA分析结果 -->
      <div v-if="taraResults.length > 0" class="section-card">
        <h2>威胁分析结果 ({{ taraResults.length }})</h2>
        <div class="section-content">
          <table class="data-table">
            <thead>
              <tr>
                <th>资产ID</th>
                <th>资产名称</th>
                <th>STRIDE</th>
                <th>威胁场景</th>
                <th>攻击向量</th>
                <th>影响等级</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(result, index) in taraResults" :key="index">
                <td>{{ result.asset_id }}</td>
                <td>{{ result.asset_name }}</td>
                <td>
                  <span class="stride-badge">{{ result.stride_model }}</span>
                </td>
                <td class="threat-cell">{{ result.threat_scenario }}</td>
                <td>{{ result.attack_vector }}</td>
                <td>
                  <span :class="['impact-badge', getImpactClass(result.operational_impact)]">
                    {{ result.operational_impact }}
                  </span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <!-- 术语表 -->
      <div v-if="terminology.length > 0" class="section-card">
        <h2>术语表</h2>
        <div class="section-content">
          <table class="data-table">
            <thead>
              <tr>
                <th>缩写</th>
                <th>英文全称</th>
                <th>中文名称</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="term in terminology" :key="term.abbreviation">
                <td>{{ term.abbreviation }}</td>
                <td>{{ term.english }}</td>
                <td>{{ term.chinese }}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </template>

    <!-- 图片预览模态框 -->
    <div v-if="imageModal.show" class="modal-overlay" @click="closeImageModal">
      <div class="modal-content image-modal" @click.stop>
        <div class="modal-header">
          <h3>{{ imageModal.title }}</h3>
          <button class="btn-close" @click="closeImageModal">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
              <line x1="18" y1="6" x2="6" y2="18"/>
              <line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
          </button>
        </div>
        <div class="modal-body">
          <img :src="imageModal.url" :alt="imageModal.title">
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { getReport, getDownloadUrl, getImageUrl } from '@/api'

const route = useRoute()
const isLoading = ref(true)
const report = ref(null)

const imageModal = ref({
  show: false,
  url: '',
  title: ''
})

// 计算属性
const downloadUrl = computed(() => {
  return report.value ? getDownloadUrl(report.value.id) : ''
})

const assets = computed(() => {
  return report.value?.assets?.assets || []
})

const taraResults = computed(() => {
  return report.value?.tara_results?.results || []
})

const terminology = computed(() => {
  return report.value?.definitions?.terminology || []
})

const hasImages = computed(() => {
  const defs = report.value?.definitions || {}
  const assets = report.value?.assets || {}
  return defs.item_boundary_image || 
         defs.system_architecture_image || 
         defs.software_architecture_image ||
         assets.dataflow_image
})

// 生命周期
onMounted(async () => {
  const reportId = route.params.id
  try {
    const data = await getReport(reportId)
    report.value = data
  } catch (error) {
    console.error('获取报告详情失败:', error)
  } finally {
    isLoading.value = false
  }
})

// 方法
function formatDate(dateStr) {
  const date = new Date(dateStr)
  return date.toLocaleString('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  })
}

function getImageSrc(imagePath) {
  if (!imagePath) return ''
  if (imagePath.startsWith('/api/')) return imagePath
  if (imagePath.startsWith('http')) return imagePath
  // 从路径中提取图片ID
  const match = imagePath.match(/IMG-[a-f0-9]+/i)
  if (match) {
    return getImageUrl(match[0])
  }
  return imagePath
}

function getImpactClass(impact) {
  const map = {
    '严重的': 'critical',
    '重大的': 'high',
    '中等的': 'medium',
    '可忽略不计的': 'low'
  }
  return map[impact] || 'medium'
}

function showImageModal(imagePath, title) {
  imageModal.value = {
    show: true,
    url: getImageSrc(imagePath),
    title
  }
}

function closeImageModal() {
  imageModal.value = { show: false, url: '', title: '' }
}
</script>

<style scoped>
.report-detail-page {
  max-width: 1200px;
  margin: 0 auto;
}

.loading-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 80px 20px;
}

.loading-state svg {
  width: 40px;
  height: 40px;
  color: var(--brand-blue);
  margin-bottom: 16px;
}

.detail-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 32px;
  gap: 24px;
}

.header-left {
  display: flex;
  align-items: flex-start;
  gap: 16px;
}

.btn-back {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 8px 12px;
  border: 1px solid var(--border-color);
  border-radius: 8px;
  background: var(--bg-card);
  color: var(--text-secondary);
  cursor: pointer;
  transition: all 0.2s;
  white-space: nowrap;
}

.btn-back:hover {
  background: var(--bg-hover);
  color: var(--text-primary);
}

.btn-back svg {
  width: 16px;
  height: 16px;
}

.title-section h1 {
  font-size: 24px;
  font-weight: 600;
  margin-bottom: 8px;
}

.header-meta {
  display: flex;
  align-items: center;
  gap: 16px;
  flex-wrap: wrap;
}

.meta-item {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 13px;
  color: var(--text-muted);
}

.meta-item svg {
  width: 14px;
  height: 14px;
}

.header-actions .btn svg {
  width: 18px;
  height: 18px;
}

/* Stats Grid */
.stats-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px;
  margin-bottom: 32px;
}

.stat-card {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 20px;
  background: var(--bg-card);
  border: 1px solid var(--border-color);
  border-radius: 12px;
}

.stat-icon {
  width: 48px;
  height: 48px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 12px;
}

.stat-icon svg {
  width: 24px;
  height: 24px;
}

.stat-icon.blue { background: rgba(99,102,241,0.1); color: #6366f1; }
.stat-icon.yellow { background: rgba(245,158,11,0.1); color: #f59e0b; }
.stat-icon.red { background: rgba(239,68,68,0.1); color: #ef4444; }
.stat-icon.green { background: rgba(34,197,94,0.1); color: #22c55e; }

.stat-info .stat-value {
  font-size: 28px;
  font-weight: 700;
  display: block;
}

.stat-info .stat-label {
  font-size: 13px;
  color: var(--text-muted);
}

/* Section Cards */
.section-card {
  background: var(--bg-card);
  border: 1px solid var(--border-color);
  border-radius: 12px;
  overflow: hidden;
  margin-bottom: 24px;
}

.section-card h2 {
  font-size: 16px;
  font-weight: 600;
  margin: 0;
  padding: 16px 20px;
  border-bottom: 1px solid var(--border-color);
  background: var(--bg-secondary);
}

.section-content {
  padding: 20px;
}

.section-desc {
  color: var(--text-secondary);
  margin-bottom: 16px;
}

.info-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 16px;
}

.info-item {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.info-label {
  font-size: 12px;
  color: var(--text-muted);
}

.info-value {
  font-size: 14px;
  font-weight: 500;
}

/* Images Grid */
.images-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 16px;
}

.image-card {
  position: relative;
  border-radius: 10px;
  overflow: hidden;
  cursor: pointer;
  aspect-ratio: 16/10;
  background: var(--bg-tertiary);
}

.image-card img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.3s;
}

.image-card:hover img {
  transform: scale(1.05);
}

.image-title {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  padding: 12px;
  background: linear-gradient(transparent, rgba(0,0,0,0.8));
  font-size: 13px;
  color: white;
  font-weight: 500;
}

.functional-desc {
  color: var(--text-secondary);
  line-height: 1.8;
  white-space: pre-wrap;
}

/* Table Styles */
.data-table {
  width: 100%;
  border-collapse: collapse;
}

.data-table th,
.data-table td {
  padding: 12px 16px;
  text-align: left;
  border-bottom: 1px solid var(--border-color);
}

.data-table th {
  font-size: 12px;
  font-weight: 600;
  color: var(--text-secondary);
  text-transform: uppercase;
  background: var(--bg-secondary);
}

.data-table tr:last-child td {
  border-bottom: none;
}

.data-table tr:hover td {
  background: var(--bg-hover);
}

.attr-tag {
  display: inline-block;
  padding: 2px 8px;
  margin: 2px;
  border-radius: 4px;
  font-size: 11px;
  background: rgba(99,102,241,0.1);
  color: #6366f1;
}

.stride-badge {
  display: inline-block;
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 11px;
  font-weight: 600;
  background: rgba(139,92,246,0.15);
  color: #a78bfa;
}

.threat-cell {
  max-width: 300px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.impact-badge {
  display: inline-block;
  padding: 4px 10px;
  border-radius: 6px;
  font-size: 12px;
  font-weight: 500;
}

.impact-badge.critical { background: rgba(239,68,68,0.15); color: #ef4444; }
.impact-badge.high { background: rgba(245,158,11,0.15); color: #f59e0b; }
.impact-badge.medium { background: rgba(59,130,246,0.15); color: #3b82f6; }
.impact-badge.low { background: rgba(34,197,94,0.15); color: #22c55e; }

/* Modal */
.modal-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.7);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 100;
  backdrop-filter: blur(4px);
}

.image-modal {
  width: auto;
  max-width: 90vw;
  max-height: 90vh;
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 20px;
  border-bottom: 1px solid var(--border-color);
}

.modal-header h3 {
  font-size: 16px;
  font-weight: 600;
}

.btn-close {
  width: 32px;
  height: 32px;
  border-radius: 8px;
  border: none;
  background: transparent;
  color: var(--text-muted);
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
}

.btn-close:hover {
  background: var(--bg-hover);
  color: var(--text-primary);
}

.btn-close svg {
  width: 20px;
  height: 20px;
}

.modal-body {
  padding: 20px;
}

.modal-body img {
  max-width: 100%;
  max-height: 70vh;
  border-radius: 8px;
}

@media (max-width: 1000px) {
  .stats-grid {
    grid-template-columns: repeat(2, 1fr);
  }
  
  .detail-header {
    flex-direction: column;
  }
}

@media (max-width: 600px) {
  .stats-grid {
    grid-template-columns: 1fr;
  }
}
</style>
